const colors = ["blue", "gold", "purple", "orange", "green", "red"];
const container = document.getElementById("color-options");
const resetBtn = document.getElementById("reset");

const vpnUI = document.getElementById("vpn-ui");
const oldUI = document.getElementById("old-ui");
const connectBtn = document.getElementById("connect-btn");
const vpnIndicator = document.getElementById("vpn-indicator");
const vpnStatusText = document.getElementById("vpn-status-text");
const vpnDropdown = document.getElementById("vpn-dropdown");

let vpnConnected = false;

// Load saved color settings
function loadSettings() {
    chrome.storage.local.get(["colorList"], result => {
        const current = result.colorList || colors;
        container.innerHTML = "";

        colors.forEach(color => {
            const label = document.createElement("label");
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.value = color;
            checkbox.checked = current.includes(color);
            checkbox.addEventListener("change", saveColorSelection);
            label.appendChild(checkbox);
            label.append(" " + color);
            container.appendChild(label);
        });
    });
}

// Save selected colors
function saveColorSelection() {
    const checkedColors = [...document.querySelectorAll("input[type=checkbox]")]
        .filter(cb => cb.checked)
        .map(cb => cb.value);
    chrome.storage.local.set({ colorList: checkedColors });
}

// Reset colors to default
resetBtn.addEventListener("click", () => {
    chrome.storage.local.set({ colorList: colors }, loadSettings);
});

// Toggle VPN connection state
function toggleVPNConnection() {
    vpnConnected = !vpnConnected;
    updateVPNUI();
    saveVPNState();
}

// Update VPN UI visuals and button text
function updateVPNUI() {
    if (vpnConnected) {
        vpnIndicator.classList.add("connected");
        vpnStatusText.textContent = "Connected";
        connectBtn.textContent = "Disconnect";
    } else {
        vpnIndicator.classList.remove("connected");
        vpnStatusText.textContent = "Disconnected";
        connectBtn.textContent = "Connect";
    }
}

// Save VPN connection state in storage
function saveVPNState() {
    chrome.storage.local.set({ vpnConnected });
}

// Load VPN connection state from storage
function loadVPNState() {
    chrome.storage.local.get(["vpnConnected"], result => {
        vpnConnected = result.vpnConnected || false;
        updateVPNUI();
    });
}

// Code input handling to switch UI
let typedCode = "";
const secretCode = "2321";

window.addEventListener("keydown", (e) => {
    typedCode += e.key;
    if (!secretCode.startsWith(typedCode)) {
        typedCode = "";
    }
    if (typedCode === secretCode) {
        typedCode = "";
        // Fade out VPN UI and fade in Old UI
        vpnUI.style.transition = "opacity 0.5s ease";
        oldUI.style.transition = "opacity 0.5s ease";

        vpnUI.style.opacity = 0;
        setTimeout(() => {
            vpnUI.style.display = "none";
            oldUI.style.display = "block";
            oldUI.style.opacity = 0;
            setTimeout(() => oldUI.style.opacity = 1, 50);
        }, 500);
    }
});

// Connect button event
connectBtn.addEventListener("click", toggleVPNConnection);

// On document ready, load everything
document.addEventListener("DOMContentLoaded", () => {
    loadSettings();
    loadVPNState();
    oldUI.style.display = "none";
    vpnUI.style.opacity = 1;
});
